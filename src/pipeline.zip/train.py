import os
import mlflow
import pandas as pd
from azureml.core import Run, Dataset, Workspace
from prophet import Prophet
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

def load_data():
    """Load sales history data from Azure ML dataset."""
    run = Run.get_context()
    workspace = run.experiment.workspace
    dataset = Dataset.get_by_name(workspace, 'sales_history_data')
    df = dataset.to_pandas_dataframe()
    return df

def preprocess_data(df):
    """Preprocess data for time series forecasting."""
    # Group by week and calculate total sales
    df['date'] = pd.to_datetime(df['Transaction Year'].astype(str) + '-W' + 
                               df['Transaction Week'].astype(str) + '-1')
    
    weekly_sales = df.groupby('date').agg({
        'Volume': 'sum',
        'CV Gross Sales': 'sum',
        'CV Net Sales': 'sum',
        'CV COGS': 'sum',
        'CV Gross Profit': 'sum'
    }).reset_index()
    
    # Rename columns for Prophet
    weekly_sales = weekly_sales.rename(columns={'date': 'ds', 'Volume': 'y'})
    return weekly_sales

def train_prophet_model(df):
    """Train Facebook Prophet model."""
    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=True,
        daily_seasonality=False,
        seasonality_mode='multiplicative'
    )
    
    model.fit(df)
    
    # Create future dataframe for predictions
    future = model.make_future_dataframe(periods=13, freq='W')
    forecast = model.predict(future)
    
    return model, forecast

def evaluate_model(y_true, y_pred):
    """Calculate model performance metrics."""
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    
    return {
        'MAE': mae,
        'MSE': mse,
        'RMSE': rmse
    }

def main():
    """Main training pipeline."""
    mlflow.start_run()
    
    # Load and preprocess data
    raw_data = load_data()
    processed_data = preprocess_data(raw_data)
    
    # Train Prophet model
    model, forecast = train_prophet_model(processed_data)
    
    # Evaluate model
    metrics = evaluate_model(
        processed_data['y'],
        forecast['yhat'][:len(processed_data)]
    )
    
    # Log metrics
    for metric_name, metric_value in metrics.items():
        mlflow.log_metric(metric_name, metric_value)
    
    # Save model
    mlflow.prophet.log_model(model, "prophet_model")
    
    # Log forecast as artifact
    forecast.to_csv('forecast.csv', index=False)
    mlflow.log_artifact('forecast.csv')
    
    mlflow.end_run()

if __name__ == "__main__":
    main()
